public class Foo implements java.io.Serializable
{
	int ival;
	String[] svals;
	double dval;
	transient double tdval;

	public Foo(int iv, String[] svs, double dv)
	{
		ival = iv;
		svals = svs;
		dval = dv;	
		settdval();
	}

	public void settdval()
	{
		tdval = ((double)ival) + dval;
	}

	public void describe()
	{
		String string = new String();

		for(String word: svals)
			string += "," + word;

		System.out.println("ival: " + ival +
							"\ndval: " + dval +
							"\nsvals: " + string + 
							"\ntdval: " + tdval);
	}
}
