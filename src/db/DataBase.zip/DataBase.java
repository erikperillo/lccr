import java.io.*;

public class DataBase implements IDataBase
{
	private static final String ROOT = DataBase.class.getProtectionDomain().getCodeSource().getLocation().getPath() + "/" + "data";
	private static DataBase db = null;

	//test method
	public static void main(String[] argv)
	{
		final String usage = "Usage: java DataBase [save|load] filename";

		if(argv.length < 2)
		{
			System.out.println(usage);
			System.exit(0);
		}

		DataBase db = DataBase.getInstance();
		Foo foo;

		if(argv[0].equalsIgnoreCase("save"))
		{
			String[] strs = {"ey b0ss","can","i","habe"};
			foo = new Foo(-891,strs,0.1209);

			try
			{
				db.save(foo,argv[1]);
			}
			catch(IOException e)
			{
				System.out.println("Error: could not save file!");
				System.exit(1);		
			}

			System.out.println("Object saved");
		}
		else if(argv[0].equalsIgnoreCase("load"))
		{
			try
			{
				foo = (Foo)db.load(argv[1]);	
				System.out.println("Object loaded:");
				foo.describe();
			}
			catch(IOException | ClassNotFoundException e)
			{
				System.out.println("Error: could not load object!");
				System.exit(1);		
			}
		}
		else
		{
			System.out.println("Error: invalid arguments\n" + usage);
			System.exit(1);
		}
	}

	private DataBase()
	{
		File file = new File(DataBase.ROOT);
		
		if(!file.exists())
			file.mkdirs();
	}

	public static DataBase getInstance()
	{
		if(DataBase.db == null)
			DataBase.db = new DataBase();
	
		return DataBase.db;
	}			
			
	public void save(Object obj, String filename) throws IOException
	{
		FileOutputStream fos;
		ObjectOutputStream oos;

		try
		{
			fos = new FileOutputStream(DataBase.ROOT + "/" + filename);
			oos = new ObjectOutputStream(fos);

			oos.writeObject(obj);

			oos.close();
		}
		catch(IOException e)
		{
			throw e;
		}
	}

	public Object load(String filename) throws IOException, ClassNotFoundException
	{
		FileInputStream fis;
		ObjectInputStream ois;
		Object obj;

		try
		{
			fis = new FileInputStream(DataBase.ROOT + "/" + filename);
			ois = new ObjectInputStream(fis);

			obj = ois.readObject();

			ois.close();
		}
		catch(IOException e)
		{
			throw e;
		}
		catch(ClassNotFoundException e)
		{
			throw e;
		}
	
		return obj;
	}
}
